from flask import *
from random import *

port = int(input("Port: "))

host = str(input("Host(IP for the server): "))

class First():
    def __init__(self, value):
        self.value = int(value)
        self.res = randrange(100)
        self.added = self.value + self.res
    def __str__(self):
        return f"{self.value} + {self.res} = {self.added}"
    
class Second():
    def __init__(self, value):
        self.value = int(value)
        self.res = randrange(100)
        self.added = self.value + self.res
    def __str__(self):
        return f"{self.value} + {self.res} = {self.added}"

First_value = int(input("Enter first number: "))
Second_value = int(input("Enter second number: "))

def Guess_who_is_bigger(guess):
    if guess == "first" or "First":
        if First_value > Second_value:
            return "Correct! First number is bigger"
        else:
            return "Wrong! First number is smaller"

    if guess == "second" or "Second":
        if Second_value > First_value:
            return "Correct! Second number is bigger"
        else:
            return "Wrong! Second number is smaller"

def main():
    guessed = Guess_who_is_bigger(input("Guess who is bigger: "))
    app = Flask(__name__)
    @app.route('/')
    def check_guessed():
        return f"<h1>Hi bro, your guess: {guessed}<h1> <style>body {'background-color: #120122'}</style>"
    app.run(host, port, debug=True)

if __name__ == "__main__":
    main()


    
