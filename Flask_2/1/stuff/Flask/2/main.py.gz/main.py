from flask import *
from random import *
from colorama import *
from math import *
from os import *
from pymongo import *
system("")
init()

port = int(input("Port: "))

host = str(input("Host(IP of the server): "))

class ROUND_SQRT:
    def __init__(self, value, precision):
        self.value = value
        self.precision = precision
        self.sqrt = round(sqrt(self.value) + precision, self.precision)
    def __str__(self):
        return f"VALUE: {self.value} | PRECISION: {self.precision} | SQRT: {self.sqrt}"

def check_value():
    global ROUND_sqrt
    ROUND_sqrt = ROUND_SQRT(randint(1, 100), randint(1, 10))
    if ROUND_sqrt.sqrt == round(sqrt(ROUND_sqrt.value) + ROUND_sqrt.precision, ROUND_sqrt.precision):
        return f"True. + {ROUND_sqrt}"
        
    else:
        return f"False. + {ROUND_sqrt}"

def main():
    app = Flask(__name__)
    hex = "#" + input("HEX: ")
    if hex == "#random":
        hex = "#" + str(randint(0, 16777215))
    @app.route("/")
    def index():
        global hex
        return f"<h1>{check_value()}</h1><style>h1{'{color: red}' if ROUND_sqrt.sqrt != round(sqrt(ROUND_sqrt.value) + ROUND_sqrt.precision, ROUND_sqrt.precision) else '{color: green}'}h1 {{position: absolute; top:45%; right:27%; transform: translate:(-50%, -50%);}} body{{background: {hex};}}</style>"
    @app.route("/check")
    def test():
        post_data = request.args["post_data"]
        if post_data == "":
            for i in range(100):
                post_data += str(i)
        if post_data == "rickroll":
                return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        elif post_data == "ip":
            return request.remote_addr
        elif post_data == "code":
            return "<h1>Really? GO the inspect element and copy the code.</h1><style>h1{'{color: red}'}h1 {{position: absolute; top:45%; right:27%; transform: translate:(-50%, -50%);}}</style>"
        else:
            return f"<h1>{post_data}</h1><style>h1{{position: absolute; top:45%; right:50%; transform: translate:(-50%, -50%);}}</style>"
        
    app.run(host, port, debug=True)

if __name__ == "__main__":
    main()
